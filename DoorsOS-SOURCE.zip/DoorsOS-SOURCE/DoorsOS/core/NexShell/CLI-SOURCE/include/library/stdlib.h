#ifndef LIBRARY_STDLIB_H
#define LIBRARY_STDLIB_H

void exit( int code );

#endif

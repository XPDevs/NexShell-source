/*
Copyright (C) 2015-2019 The University of Notre Dame
This software is distributed under the GNU General Public License.
See the file LICENSE for details.
*/

#include "elf.h"
#include "fs.h"
#include "string.h"
#include "console.h"
#include "process.h"
#include "kernel/syscall.h"
#include "memorylayout.h"

struct elf_header {
    char ident[16];
    uint16_t type;
    uint16_t machine;
    uint32_t version;
    uint32_t entry;
    uint32_t program_offset;
    uint32_t section_offset;
    uint32_t flags;
    uint16_t header_size;
    uint16_t phentsize;
    uint16_t phnum;
    uint16_t shentsize;
    uint16_t shnum;
    uint16_t shstrndx;
};

#define ELF_HEADER_TYPE_EXECUTABLE 2
#define ELF_HEADER_MACHINE_I386    3
#define ELF_HEADER_VERSION         1

struct elf_program {
    uint32_t type;
    uint32_t offset;
    uint32_t vaddr;
    uint32_t paddr;
    uint32_t file_size;
    uint32_t memory_size;
    uint32_t flags;
    uint32_t align;
};

#define ELF_PROGRAM_TYPE_LOADABLE 1

struct elf_section {
    uint32_t name;
    uint32_t type;
    uint32_t flags;
    uint32_t address;
    uint32_t offset;
    uint32_t size;
    uint32_t link;
    uint32_t info;
    uint32_t alignment;
    uint32_t entry_size;
};

#define ELF_SECTION_TYPE_NULL 0
#define ELF_SECTION_TYPE_PROGRAM 1
#define ELF_SECTION_TYPE_BSS 8

/* Helper: make sure process address space covers given addr */
static int elf_ensure_address_space(struct process *p, uint32_t addr) {
    if (addr < PROCESS_ENTRY_POINT) {
        return 0; // no need to grow below entry point
    }

    uint32_t size_needed = addr - PROCESS_ENTRY_POINT;
    // Round up to PAGE_SIZE boundary
    uint32_t overflow = size_needed % PAGE_SIZE;
    if (overflow != 0) {
        size_needed += PAGE_SIZE - overflow;
    }

    if (size_needed > p->vm_data_size) {
        return process_data_size_set(p, size_needed);
    }

    return 0; // already big enough
}

int elf_load(struct process *p, struct fs_dirent *d, addr_t *entry) {
    struct elf_header header;
    int i, res;
    
    // Read ELF header
    int actual = fs_dirent_read(d, (char *)&header, sizeof(header), 0);
    if (actual != sizeof(header)) {
        printf("elf: failed to read ELF header\n");
        return KERROR_NOT_FOUND;
    }

    // Validate ELF magic, machine type, and version
    if (strncmp(header.ident, "\177ELF", 4) != 0) {
        printf("elf: bad ELF magic\n");
        return KERROR_NOT_EXECUTABLE;
    }
    if (header.machine != ELF_HEADER_MACHINE_I386) {
        printf("elf: unsupported machine (not i386)\n");
        return KERROR_NOT_EXECUTABLE;
    }
    if (header.version != ELF_HEADER_VERSION) {
        printf("elf: unsupported ELF version\n");
        return KERROR_NOT_EXECUTABLE;
    }
    if (header.type != ELF_HEADER_TYPE_EXECUTABLE) {
        printf("elf: ELF is not executable type\n");
        return KERROR_NOT_EXECUTABLE;
    }

    // Read program headers (only first one supported here)
    if (header.phnum < 1) {
        printf("elf: no program headers found\n");
        return KERROR_NOT_EXECUTABLE;
    }

    struct elf_program program;
    actual = fs_dirent_read(d, (char *)&program, sizeof(program), header.program_offset);
    if (actual != sizeof(program)) {
        printf("elf: failed to read program header\n");
        return KERROR_NOT_EXECUTABLE;
    }

    if (program.type != ELF_PROGRAM_TYPE_LOADABLE) {
        printf("elf: program header not loadable\n");
        return KERROR_NOT_EXECUTABLE;
    }
    if (program.vaddr < PROCESS_ENTRY_POINT) {
        printf("elf: program virtual address below process entry point\n");
        return KERROR_NOT_EXECUTABLE;
    }
    if (program.memory_size > 0x8000000) {
        printf("elf: program too large\n");
        return KERROR_NOT_EXECUTABLE;
    }
    if (program.memory_size < program.file_size) {
        printf("elf: memory size smaller than file size\n");
        return KERROR_NOT_EXECUTABLE;
    }

    // Allocate process memory to fit the segment
    res = process_data_size_set(p, program.memory_size);
    if (res != 0) {
        printf("elf: failed to allocate process memory\n");
        return KERROR_OUT_OF_MEMORY;
    }

    // Load segment from file to memory
    actual = fs_dirent_read(d, (char *)program.vaddr, program.file_size, program.offset);
    if (actual != program.file_size) {
        printf("elf: failed to read program segment data\n");
        return KERROR_EXECUTION_FAILED;
    }

    // Zero out the remaining memory (BSS)
    if (program.memory_size > program.file_size) {
        memset((void *)(program.vaddr + program.file_size), 0, program.memory_size - program.file_size);
    }

    // Process sections for .bss zeroing or additional data loading
    for (i = 0; i < header.shnum; i++) {
        struct elf_section section;
        actual = fs_dirent_read(d, (char *)&section, sizeof(section), header.section_offset + i * header.shentsize);
        if (actual != sizeof(section)) {
            printf("elf: failed to read section header\n");
            return KERROR_EXECUTION_FAILED;
        }

        if (section.type == ELF_SECTION_TYPE_BSS) {
            // Ensure address space
            res = elf_ensure_address_space(p, section.address + section.size);
            if (res != 0) {
                printf("elf: failed to allocate memory for BSS\n");
                return KERROR_OUT_OF_MEMORY;
            }
            // Zero BSS
            memset((void *)section.address, 0, section.size);
        } else if (section.type == ELF_SECTION_TYPE_PROGRAM && section.address != 0) {
            // Load other program sections (data)
            res = elf_ensure_address_space(p, section.address + section.size);
            if (res != 0) {
                printf("elf: failed to allocate memory for section\n");
                return KERROR_OUT_OF_MEMORY;
            }
            actual = fs_dirent_read(d, (char *)section.address, section.size, section.offset);
            if (actual != section.size) {
                printf("elf: failed to load section data\n");
                return KERROR_EXECUTION_FAILED;
            }
        }
    }

    // Set process entry point from ELF header
    *entry = header.entry;

    return 0;
}

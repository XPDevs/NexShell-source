/*
Copyright (C) 2016-2019 The University of Notre Dame
This software is distributed under the GNU General Public License.
See the file LICENSE for details.

All modifiactions are copyrighted to XPDevs and James Turner
XPDevs and James Turner use basekernel as a base where mods are added and updated
for the NexShell kernel
*/

#include "kernel/types.h"
#include "kernel/error.h"
#include "kernel/ascii.h"
#include "kshell.h"
#include "console.h"
#include "string.h"
#include "rtc.h"
#include "kmalloc.h"
#include "page.h"
#include "process.h"
#include "main.h"
#include "fs.h"
#include "syscall_handler.h"
#include "clock.h"
#include "kernelcore.h"
#include "bcache.h"
#include "printf.h"
#include "graphics.h" // Include your graphics header

// define the start screen for when the gui starts
#define COLOR_BLUE  0x0000FF      // RGB hex for blue (blue channel max)
#define COLOR_WHITE 0xFFFFFF      // White color

// DO NOT TOUCH THESE
#define PM1a_CNT_BLK 0xB004      // Example ACPI PM1a control port (adjust per your ACPI)
#define SLP_TYP1    (0x5 << 10)  // Sleep type 1 for shutdown (example value)
#define SLP_EN      (1 << 13)

static int kshell_mount( const char *devname, int unit, const char *fs_type)
{
	if(current->ktable[KNO_STDDIR]) {
		printf("root filesystem already mounted, please unmount first\n");
		return -1;
	}

	struct device *dev = device_open(devname,unit);
	if(dev) {
		struct fs *fs = fs_lookup(fs_type);
		if(fs) {
			struct fs_volume *v = fs_volume_open(fs,dev);
			if(v) {
				struct fs_dirent *d = fs_volume_root(v);
				if(d) {
					current->ktable[KNO_STDDIR] = kobject_create_dir(d);
					return 0;
				} else {
					printf("mount: couldn't find root dir on %s unit %d!\n",device_name(dev),device_unit(dev));
					return -1;
				}
				fs_volume_close(v);
			} else {
				printf("mount: couldn't mount %s on %s unit %d\n",fs_type,device_name(dev),device_unit(dev));
				return -1;
			}
		} else {
			printf("mount: invalid fs type: %s\n", fs_type);
			return -1;
		}
		device_close(dev);
	} else {
		printf("mount: couldn't open device %s unit %d\n",devname,unit);
		return -1;
	}

	return -1;
}


static int kshell_printdir(const char *d, int length)
{
	while(length > 0) {
		printf("%s\n", d);
		int len = strlen(d) + 1;
		d += len;
		length -= len;
	}
	return 0;
}

static int kshell_listdir(const char *path)
{
	struct fs_dirent *d = fs_resolve(path);
	if(d) {
		int buffer_length = 1024;
		char *buffer = kmalloc(buffer_length);
		if(buffer) {
			int length = fs_dirent_list(d, buffer, buffer_length);
			if(length>=0) {
				kshell_printdir(buffer, length);
			} else {
				printf("list: %s is not a directory\n", path);
			}
			kfree(buffer);
		}
	} else {
		printf("list: %s does not exist\n", path);
	}

	return 0;
}

static int kshell_execute(int argc, const char **argv)
{
    if (argc < 1) {
        printf("No command provided.\n");
        return -1;
    }

    const char *cmd = argv[0];

    if (!strcmp(cmd, "start")) {
        if (argc > 1) {
            int fd = sys_open_file(KNO_STDDIR, argv[1], 0, 0);
            if (fd >= 0) {
                int pid = sys_process_run(fd, argc - 1, &argv[1]);
                if (pid > 0) {
                    printf("started process %d\n", pid);
                    process_yield();
                } else {
                    printf("couldn't start %s\n", argv[1]);
                }
                sys_object_close(fd);
            } else {
                printf("couldn't find %s\n", argv[1]);
            }
        } else {
            printf("start: requires argument.\n");
        }
    } else if (!strcmp(cmd, "run")) {
        if (argc > 1) {
            int fd = sys_open_file(KNO_STDDIR, argv[1], 0, 0);
            if (fd >= 0) {
                int pid = sys_process_run(fd, argc - 1, &argv[1]);
                if (pid > 0) {
                    printf("started process %d\n", pid);
                    process_yield();
                    struct process_info info;
                    process_wait_child(pid, &info, -1);
                    printf("process %d exited with status %d\n", info.pid, info.exitcode);
                    process_reap(info.pid);
                } else {
                    printf("couldn't start %s\n", argv[1]);
                }
                sys_object_close(fd);
            } else {
                printf("couldn't find %s\n", argv[1]);
            }
        } else {
            printf("run: requires argument\n");
        }
    } else if (!strcmp(cmd, "list")) {
        if (argc > 1) {
            printf("\nFiles of '%s'\n", argv[1]);
            kshell_listdir(argv[1]);
        } else {
            printf("\nFiles of '/'\n");
            kshell_listdir(".");
        }
    } else if (!strcmp(cmd, "mount")) {
        if (argc == 4) {
            int unit;
            if (str2int(argv[2], &unit)) {
                kshell_mount(argv[1], unit, argv[3]);
            } else {
                printf("mount: expected unit number but got %s\n", argv[2]);
            }
        } else {
            printf("mount: requires device, unit, and fs type\n");
        }
    } else if (!strcmp(cmd, "kill")) {
        if (argc > 1) {
            int pid;
            if (str2int(argv[1], &pid)) {
                process_kill(pid);
            } else {
                printf("kill: expected process id number but got %s\n", argv[1]);
            }
        } else {
            printf("kill: requires argument\n");
        }
	} else if(!strcmp(cmd, "mkdir")) {
		if(argc == 3) {
			struct fs_dirent *dir = fs_resolve(argv[1]);
			if(dir) {
				struct fs_dirent *n = fs_dirent_mkdir(dir,argv[2]);
				if(!n) {
					printf("mkdir: couldn't create %s\n",argv[2]);
				} else {
					fs_dirent_close(n);
				}
				fs_dirent_close(dir);
			} else {
				printf("mkdir: couldn't open %s\n",argv[1]);
			}
		} else {
			printf("use: mkdir <parent-dir> <dirname>\n");
		} 
} else if (!strcmp(cmd, "reboot")) {
        reboot();
   } else if (!strcmp(cmd, "shutdown")) {
    if (argc > 1 && !strcmp(argv[1], "cowsay")) {
        // User wants shutdown cowsay <message>
        if (argc > 2) {
            // Combine all args after "cowsay" into one message
            int total_len = 0;
            for (int i = 2; i < argc; i++) {
                total_len += strlen(argv[i]) + 1; // space or terminator
            }

            char *msg = kmalloc(total_len);
            if (!msg) {
                printf("shutdown cowsay: memory allocation failed.\n");
                return -1;
            }

            msg[0] = '\0';
            for (int i = 2; i < argc; i++) {
                strcat(msg, argv[i]);
                if (i < argc - 1) strcat(msg, " ");
            }

            cowsay(msg);
            kfree(msg);
        } else {
            printf("Usage: shutdown cowsay <message>\n");
            return -1;
        }
    }
    // Then proceed with shutdown normally
    shutdown_user();
} else if (!strcmp(cmd, "clear")) {
        clear();
    } else if (!strcmp(cmd, "neofetch")) {
        neofetch();
    } else if (!strcmp(cmd, "startGUI")) {
        GUI();
    } else if (!strcmp(cmd, "automount")) {
        automount();
} else if (!strcmp(cmd, "unmount")) {
if (current->ktable[KNO_STDDIR]) {
        printf("\nunmounting root directory\n");
        sys_object_close(KNO_STDDIR);
    } else {
        printf("\nnothing currently mounted\n");
    }
} else if (!strcmp(cmd, "cowsay")) {
    if (argc > 1) {
        // Calculate total length for the message
        int total_len = 0;
        for (int i = 1; i < argc; i++) {
            total_len += strlen(argv[i]) + 1; // +1 for space or 0 terminator
        }

        char *msg = kmalloc(total_len);
        if (!msg) {
            printf("cowsay: memory allocation failed.\n");
            return -1;
        }

        msg[0] = '\0';
        for (int i = 1; i < argc; i++) {
            strcat(msg, argv[i]);
            if (i < argc - 1) strcat(msg, " ");
        }

        cowsay(msg);
        kfree(msg);
    } else {
        printf("Usage: cowsay <message>\n");
    }
} else if (!strcmp(cmd, "contents")) {
    if (argc > 1) {
        const char *filepath = argv[1];
        printf("Reading file: %s\n", filepath);

        int fd = sys_open_file(KNO_STDDIR, filepath, 0, 0);
        if (fd < 0) {
            printf("Failed to open file: %s\n", filepath);
            return 0;
        }

        char *buffer = kmalloc(4096);
        if (!buffer) {
            printf("Memory allocation failed\n");
            sys_object_close(fd);
            return 0;
        }

        int bytes_read = sys_object_read(fd, buffer, 4096);
        if (bytes_read > 0) {
            buffer[bytes_read] = '\0';
            printf("\f%s\n", buffer);  // Clear screen before showing contents
        } else {
            printf("File read failed or is empty\n");
        }

        kfree(buffer);
        sys_object_close(fd);

        __asm__ __volatile__ (
            "mov $100000000, %%ecx\n"
            "1:\n"
            "dec %%ecx\n"
            "jnz 1b\n"
            :
            :
            : "ecx"
        );
    } else {
        printf("Usage: contents <filepath>\n");
    } 
} else if (!strcmp(cmd, "echo")) {
    if (argc > 1) {
        for (int i = 1; i < argc; i++) {
            printf("%s", argv[i]);
            if (i < argc - 1) printf(" ");
        }
        printf("\n");
    } else {
        printf("\n"); // If just "echo" is typed, print a blank line
    }
} else if (!strcmp(cmd, "help")) {
           if (argc == 1) {
        printf("\nCommands:\n");
        printf("start <path> <args>\n");
        printf("run <path> <args>\n");
        printf("list <directory>\n");
        printf("mount <device> <unit> <fstype>\n");
        printf("kill <pid>\n");
        printf("reboot\n");
        printf("shutdown\n");
        printf("clear\n");
        printf("neofetch\n");
        printf("startGUI\n");
        printf("automount\n");
        printf("unmount\n");
        printf("help <command>\n");
        printf("contents <file>\n");
        printf("cowsay\n\n");
        } else {
            printf("\n");
        }
    } else {
        printf("%s: command not found :(\n", argv[0]);
    }

    return 0;
}



int kshell_readline(char *line, int length)
{
	int i = 0;
	while(i < (length - 1)) {
		char c = console_getchar(&console_root);
		if(c == ASCII_CR) {
			line[i] = 0;
			printf("\n");
			return 1;
		} else if(c == ASCII_BS) {
			if(i > 0) {
				putchar(c);
				i--;
			}
		} else if(c >= 0x20 && c <= 0x7E) {
			putchar(c);
			line[i] = c;
			i++;
		}
	}

	return 0;
}

void cowsay(const char *message) {
    int len = strlen(message);
    int i;

    // Top of bubble
    printf(" ");
    for (i = 0; i < len + 2; i++) printf("_");
    printf("\n");

    // Bubble with message
    printf("< %s >\n", message);

    // Bottom of bubble
    printf(" ");
    for (i = 0; i < len + 2; i++) printf("-");
    printf("\n");

    // Cow ASCII art
    printf("        \\   ^__^\n");
    printf("         \\  (oo)\\_______\n");
    printf("            (__)\\       )\\/\\\n");
    printf("                ||----w |\n");
    printf("                ||     ||\n");
}


////////////////////////////////////////////////////////////
// everything past this point is for system interactions //
//////////////////////////////////////////////////////////


int automount()
{
	int i;

	for(i=0;i<4;i++) {
		printf("automount: trying atapi unit %d.\n",i);
		if(kshell_mount("atapi",i,"cdromfs")==0) return 0;
	}

	for(i=0;i<4;i++) {
		printf("automount: trying ata unit %d.\n",i);
		if(kshell_mount("ata",i,"simplefs")==0) return 0;
	}

	printf("automount: no bootable devices available.\n");
	return -1;
}

void shutdown_user() {
    clear();
    // main message for shutdown
    printf("Powering off... ");
    // inside this will be containing all of the background processes of shutting down
    // that will consist of stopping all the background processes, unmounting disk and rootfs
    // as well as then running the acpi command to poweroff the cpu
    // if the computer cant be shutdown using the acpi it warns the user and halts the system for it to force powered off

   // first process is to kill them all as well as the children
    for (int pid = 2; pid <= 100; pid++) {
        process_kill(pid);
        if ((pid - 1) % 10 == 0) {
        }
    }

   // unmount the disk and root file system
if (current->ktable[KNO_STDDIR]) {
        sys_object_close(KNO_STDDIR);
    } else {
    }


    // wait to show the user it had been proceesing stuff
        __asm__ __volatile__ (
        "mov $400000000, %%ecx\n"
        "1:\n"
        "dec %%ecx\n"
        "jnz 1b\n"
        :
        :
        : "ecx"
    );

// print that it was successful of shutting it down just before the acpi
printf("Done\n");

    // wait to make it smooth instead of the rush
        __asm__ __volatile__ (
        "mov $400000000, %%ecx\n"
        "1:\n"
        "dec %%ecx\n"
        "jnz 1b\n"
        :
        :
        : "ecx"
    );


    // acpi command to poweroff the cpu
    __asm__ __volatile__ (
        "mov $0x604, %%dx\n\t"
        "mov $0x2000, %%ax\n\t"
        "out %%ax, %%dx\n\t"
        :
        :
        : "ax", "dx"
    );

// make the user force poweroff the system if it can be turned off by the acpi
// display the warning message and then halt the cpu

    clear();
    printf("System halted.\n");
    printf("The system could not be shut down via ACPI.\n");

    halt();
}

int GUI() {
    printf("\nThe GUI is being loaded, please wait...\n");

    // Delay loop for realism
    __asm__ __volatile__ (
        "mov $400000000, %%ecx\n"
        "1:\n"
        "dec %%ecx\n"
        "jnz 1b\n"
        :
        :
        : "ecx"
    );

    // --- Load boot.nex ---
    // in this it will load the boot screen every time no matter the boot.nex
    // 

    // Delay between boot and main GUI
    __asm__ __volatile__ (
        "mov $200000000, %%ecx\n"
        "1:\n"
        "dec %%ecx\n"
        "jnz 1b\n"
        :
        :
        : "ecx"
    );

    // --- Load main.nex ---
    int main_fd = sys_open_file(KNO_STDDIR, "/core/gui/render/boot.nex", 0, 0);
    if (main_fd < 0) {
        printf("GUI: Failed to open /core/gui/render/boot.nex\n");
        return -1;
    }

    char *main_buffer = kmalloc(4096);
    if (!main_buffer) {
        printf("GUI: Memory allocation failed for boot screen\n");
        sys_object_close(main_fd);
        return -1;
    }

    int main_bytes = sys_object_read(main_fd, main_buffer, 4096);
    if (main_bytes > 0) {
        main_buffer[main_bytes] = '\0';
        printf("%s\n", main_buffer);  // Render main screen
    } else {
        printf("GUI: Main GUI read failed or is empty\n");
    }

    kfree(main_buffer);
    sys_object_close(main_fd);

    return 0;
}


void neofetch() {
    const char *architecture = "x86";
    const char *shell = "Kshell";

    printf("\n");
    printf("|----------------------------------------------------------|\n");
    printf("|                     NexShell v0.3.1-alpha                |\n");
    printf("|                  (C)Copyright 2025 XPDevs                |\n");
    printf("|                  Build id: NS127-0425-S1                 |\n");
    printf("|----------------------------------------------------------|\n");
    printf("| Architecture: %s\n", architecture);
    printf("| Shell: %s\n", shell);
    printf("| Video: %d x %d\n", video_xres, video_yres);
    printf("| Kernel size: %d bytes\n", kernel_size);
    printf("|----------------------------------------------------------|\n\n");
}


void clear() {
printf("\f\n");
}


int kshell_launch()
{
	char line[1024];
	const char *argv[100];
	int argc;
// everything past here for control
printf("\nACPI: initialized\n");

    // Try to mount the root filesystem
    printf("Mounting root filesystem\n");

automount();
neofetch(); // print system info

// go straight into the GUI but command line if it has any errors
GUI();

	while(1) {
               printf("\n");
		printf("root@Doors: /core/NexShell# ");
		kshell_readline(line, sizeof(line));

		argc = 0;
		argv[argc] = strtok(line, " ");
		while(argv[argc]) {
			argc++;
			argv[argc] = strtok(0, " ");
		}

		        if (argc > 0) {
            // Check for 'then' keyword
            int then_index = -1;
            for (int i = 0; i < argc; i++) {
                if (!strcmp(argv[i], "then")) {
                    then_index = i;
                    break;
                }
            }

            if (then_index != -1) {
                // Split into two commands
                int result;

                // First command before 'then'
                argv[then_index] = 0;
                result = kshell_execute(then_index, argv);

                // If successful, run second command
                if (result == 0) {
                    const char *argv2[100];
                    int argc2 = 0;

                    for (int i = then_index + 1; i < argc && argv[i]; i++) {
                        argv2[argc2++] = argv[i];
                    }

                    if (argc2 > 0) {
                        kshell_execute(argc2, argv2);
                    }
                }
            } else {
                // Single command
                kshell_execute(argc, argv);
            }
        }

	}
	return 0;
}